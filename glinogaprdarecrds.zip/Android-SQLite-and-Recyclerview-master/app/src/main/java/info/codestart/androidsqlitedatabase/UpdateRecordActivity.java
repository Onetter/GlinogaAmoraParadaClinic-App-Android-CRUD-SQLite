package info.codestart.androidsqlitedatabase;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import info.codestart.androidsqlitedatabase.Utils.PersonDBHelper;
import info.codestart.androidsqlitedatabase.model.Person;

public class UpdateRecordActivity extends AppCompatActivity {

    private EditText mNameEditText;
    private EditText mAgeEditText;
    private EditText mAddressEditText;
    private EditText mDateEditText;
    private EditText mContactNumberText;
    private EditText mLeftEyeGradeEditText;
    private EditText mRightEyeGradeEditText;
    private EditText mPaymentEditText;
    private Button UpdateUser;

    private PersonDBHelper dbHelper;
    private long receivedPersonId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_record);

        mNameEditText = findViewById(R.id.userNameUpdate);
        mAgeEditText = findViewById(R.id.userAgeUpdate);
        mAddressEditText = findViewById(R.id.userAddressUpdate);
        mDateEditText = findViewById(R.id.userDateUpdate);
        mContactNumberText = findViewById(R.id.userContactNumberUpdate);
        mLeftEyeGradeEditText = findViewById(R.id.userLeftEyeGradeUpdate);
        mRightEyeGradeEditText = findViewById(R.id.userRightEyeGradeUpdate);
        mPaymentEditText = findViewById(R.id.userPaymentUpdate);
        UpdateUser = findViewById(R.id.UpdateUser);

        dbHelper = new PersonDBHelper(this);



        try {
            //get intent to get person id
            receivedPersonId = getIntent().getLongExtra("USER_ID", 1);
        } catch (Exception e) {
            e.printStackTrace();
        }

        /***populate user data before update***/
        Person queriedPerson = dbHelper.getPerson(receivedPersonId);
        //set field to this user data
        mNameEditText.setText(queriedPerson.getName());
        mAgeEditText.setText(queriedPerson.getAge());
        mAddressEditText.setText(queriedPerson.getAddress());
        mDateEditText.setText(queriedPerson.getDate());
        mContactNumberText.setText(queriedPerson.getContactnumber());
        mLeftEyeGradeEditText.setText(queriedPerson.getLefteyegrade());
        mRightEyeGradeEditText.setText(queriedPerson.getRighteyegrade());
        mPaymentEditText.setText(queriedPerson.getPayment());




        //listen to add button click to update
        UpdateUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //call the save person method
                updateUser();
            }
        });

    }

    private void updateUser(){

        String name = mNameEditText.getText().toString().trim();
        String age = mAgeEditText.getText().toString().trim();
        String address = mAddressEditText.getText().toString().trim();
        String date = mDateEditText.getText().toString().trim();
        String contactnumber = mContactNumberText.getText().toString().trim();
        String lefteyegrade =  mLeftEyeGradeEditText.getText().toString().trim();
        String righteyegrade = mRightEyeGradeEditText.getText().toString().trim();
        String payment = mPaymentEditText.getText().toString().trim();

        if(name.isEmpty() && age.isEmpty()&& address.isEmpty()&& date.isEmpty()&& contactnumber.isEmpty()&& lefteyegrade.isEmpty()&& righteyegrade.isEmpty()&& payment.isEmpty() ){
            Toast.makeText(this,"You must fill up all fields", Toast.LENGTH_SHORT).show();
        }

        Person updatedPersonRecord = new Person(name, age, address, date, contactnumber, lefteyegrade, righteyegrade, payment);
        dbHelper.updatePersonRecord(receivedPersonId, this, updatedPersonRecord);
        gotolist();
    }

    private void gotolist(){
        startActivity(new Intent(this, MainActivity.class));
    }

}
