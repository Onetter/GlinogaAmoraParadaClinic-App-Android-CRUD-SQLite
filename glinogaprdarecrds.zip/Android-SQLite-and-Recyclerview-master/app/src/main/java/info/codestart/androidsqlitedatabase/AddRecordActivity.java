package info.codestart.androidsqlitedatabase;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import info.codestart.androidsqlitedatabase.Utils.PersonDBHelper;
import info.codestart.androidsqlitedatabase.model.Person;

public class AddRecordActivity extends AppCompatActivity {

    private EditText mNameEditText;
    private EditText mAgeEditText;
    private EditText mAddressEditText;
    private EditText mDateEditText;
    private EditText mContactNumberText;
    private EditText mLeftEyeGradeEditText;
    private EditText mRightEyeGradeEditText;
    private EditText mPaymentEditText;
    private Button mAddBtn;

    private PersonDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);

        mNameEditText = findViewById(R.id.userName);
        mAgeEditText = findViewById(R.id.userAge);
        mAddressEditText = findViewById(R.id.userAddress);
        mDateEditText = findViewById(R.id.userDate);
        mContactNumberText = findViewById(R.id.userContactNumber);
        mLeftEyeGradeEditText = findViewById(R.id.userLeftEyeGrade);
        mRightEyeGradeEditText = findViewById(R.id.userRightEyeGrade);
        mPaymentEditText = findViewById(R.id.userPayment);
        mAddBtn = findViewById(R.id.addNewUserButton);

        mAddBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePerson();
            }
        });

    }

    private void savePerson(){
        String name = mNameEditText.getText().toString().trim();
        String age = mAgeEditText.getText().toString().trim();
        String address = mAddressEditText.getText().toString().trim();
        String date = mDateEditText.getText().toString().trim();
        String contactnumber = mContactNumberText.getText().toString().trim();
        String lefteyegrade = mLeftEyeGradeEditText.getText().toString().trim();
        String righteyegrade = mRightEyeGradeEditText.getText().toString().trim();
        String payment = mPaymentEditText.getText().toString().trim();

        dbHelper = new PersonDBHelper(this);

        if(name.isEmpty()){
            //error name is empty
            Toast.makeText(this, "You must enter a name", Toast.LENGTH_SHORT).show();
        }

        if(age.isEmpty()){
            //error name is empty
            Toast.makeText(this, "You must enter an age", Toast.LENGTH_SHORT).show();
        }

        if(address.isEmpty()){
            //error name is empty
            Toast.makeText(this, "You must enter an address", Toast.LENGTH_SHORT).show();
        }

        if(date.isEmpty()){
            //error name is empty
            Toast.makeText(this, "You must enter a date", Toast.LENGTH_SHORT).show();
        }

        if(contactnumber.isEmpty()){
            //error name is empty
            Toast.makeText(this, "You must enter his/her lefteyegrade", Toast.LENGTH_SHORT).show();
        }

        if(lefteyegrade.isEmpty()){
            //error name is empty
            Toast.makeText(this, "You must enter his/her righteyegrade", Toast.LENGTH_SHORT).show();
        }

        if(righteyegrade.isEmpty()){
            //error name is empty
            Toast.makeText(this, "You must enter his/her payment", Toast.LENGTH_SHORT).show();
        }

        if(payment.isEmpty()){
            //error name is empty
            Toast.makeText(this, "You must enter an occupation", Toast.LENGTH_SHORT).show();
        }

        //create new person
        Person person = new Person(name, age, address, date, contactnumber, lefteyegrade, righteyegrade, payment);
        dbHelper.saveNewPerson(person);

        //finally redirect back home
        // NOTE you can implement an sqlite callback then redirect on success delete
        goBackHome();

    }

    private void goBackHome(){
        startActivity(new Intent(AddRecordActivity.this, viewList.class));
    }
}
