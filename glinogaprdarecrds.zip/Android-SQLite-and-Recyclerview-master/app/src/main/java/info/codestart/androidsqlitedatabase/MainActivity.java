package info.codestart.androidsqlitedatabase;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import info.codestart.androidsqlitedatabase.Utils.PersonAdapter;
import info.codestart.androidsqlitedatabase.Utils.PersonDBHelper;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private PersonDBHelper dbHelper;
    private PersonAdapter adapter;
    private String filter = "";
    private Button createRecord, viewRecord;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createRecord = findViewById(R.id.addBtn);
        createRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToAddUserActivity();
            }
        });

        viewRecord = findViewById(R.id.viewBtn);
        viewRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToviewListActivity();
            }
        });

    }
    private void goToAddUserActivity(){
        Intent intent = new Intent(MainActivity.this, AddRecordActivity.class);
        startActivity(intent);
    }

    private void goToviewListActivity(){
        Intent intent = new Intent(MainActivity.this, viewList.class);
        startActivity(intent);
    }
}
